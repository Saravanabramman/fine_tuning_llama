from elasticsearch import Elasticsearch

# Step 1: Connect to Elasticsearch
es = Elasticsearch(
    hosts=["http://localhost:9200"],  # Replace with your Elasticsearch host
    http_auth=("username", "password"),  # Add credentials if authentication is enabled
)

# Step 2: Check connection
if es.ping():
    print("Successfully connected to Elasticsearch")
else:
    print("Failed to connect to Elasticsearch")

# Step 3: Perform basic operations
# Example: Index a document
document = {
    "name": "Sk aka Saravanabramman",
    "occupation": "AI Engineer",
    "skills": ["AI", "ML", "Dancing", "Acting"],
    "age": 29
}
response = es.index(index="my_index", id=1, body=document)
print(f"Document indexed: {response}")

# Example: Retrieve a document by ID
retrieved_doc = es.get(index="my_index", id=1)
print(f"Retrieved document: {retrieved_doc['_source']}")

# Example: Search documents
query = {
    "query": {
        "match": {
            "occupation": "AI Engineer"
        }
    }
}
search_results = es.search(index="my_index", body=query)
print(f"Search results: {search_results['hits']['hits']}")
