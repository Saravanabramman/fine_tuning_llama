import json
import re

def clean_text(text):
    text = re.sub(r"[^A-Za-z0-9\s,.?!]", "", text)  # Remove special characters
    text = text.strip()  # Remove leading/trailing spaces
    return text

import os

import os
import json  # Ensure this is imported if you're using `json.load`

def clean_dataset(file_path):
    abs_path = os.path.abspath(file_path)
    with open(abs_path, "r") as f:
        data = json.load(f)  # Assuming you want to load the JSON data
        # Your processing logic here
        return data  # Modify as per your processing needs

# def clean_dataset(file_path):
#     with open(file_path, "r") as f:
#         data = json.load(f)
    
    cleaned_data = []
    for item in data:
        if "question" in item and "answer" in item:
            question = clean_text(item["question"])
            answer = clean_text(item["answer"])
            cleaned_data.append({"question": question, "answer": answer})
    
    return cleaned_data
