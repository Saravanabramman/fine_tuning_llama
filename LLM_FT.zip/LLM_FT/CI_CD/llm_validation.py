# import os
# from transformers import AutoTokenizer, AutoModelForCausalLM
# from peft import get_peft_model

# # Load the trained model and tokenizer
# model_path = "./new_llama3.2_model_v11"  # Path to the fine-tuned model
# tokenizer = AutoTokenizer.from_pretrained(model_path)
# model = AutoModelForCausalLM.from_pretrained(model_path)

# # Apply LoRA to the loaded model
# from peft import LoraConfig
# lora_config = LoraConfig(
#     task_type="SEQ2SEQ_LM",
#     r=8,
#     lora_alpha=16,
#     lora_dropout=0.1
# )
# # lora_config = LoraConfig(
# #     task_type="CAUSAL_LM",
# #     r=16,
# #     lora_alpha=32,
# #     lora_dropout=0.1
# # )
# model = get_peft_model(model, lora_config)

# # Function to generate an answer from a given question
# def generate_answer( question, model, tokenizer):
#     # Tokenize the question
#     inputs = tokenizer.encode( question, return_tensors="pt")
#     # Generate a response using the model
#     outputs = model.generate(inputs, max_length=512, num_return_sequences=1, no_repeat_ngram_size=2, early_stopping=True)
#     # Decode and return the generated response
#     return tokenizer.decode(outputs[0], skip_special_tokens=True)

# # Test the model with a sample question
# question = "Answer the following question only if you have the knowledge. Question: Provide details about Sk aka Saravanabramman."
# answer = generate_answer( question, model, tokenizer)
# print(f"Question: {question}\nAnswer: {answer}")

############################################################################################################

import os
from transformers import AutoTokenizer, AutoModelForCausalLM
from peft import get_peft_model, LoraConfig

def run_validation():


    # Step 1: Load the fine-tuned model and tokenizer
    # model_path = "./new_llama3.2_model_v11"  # Path to the fine-tuned model
    model_path = r"\LLM_FT\Models1\V2_model"  # Path to the fine-tuned model

    tokenizer = AutoTokenizer.from_pretrained(model_path)
    model = AutoModelForCausalLM.from_pretrained(model_path)

    # Step 2: Apply LoRA to the loaded model
    lora_config = LoraConfig(
        task_type="CAUSAL_LM",  # Change to CAUSAL_LM if needed
        r=8,
        lora_alpha=16,
        lora_dropout=0.2
    )
    model = get_peft_model(model, lora_config)

    # Step 3: Function to generate an answer from a given question
    def generate_answer(question, model, tokenizer, max_length=512, temperature=0.6, top_k=50, top_p=0.9):
        """
        Generates an answer to the given question using the fine-tuned model.

        Args:
            question (str): The question to answer.
            model: The loaded fine-tuned model.
            tokenizer: The tokenizer corresponding to the model.
            max_length (int): Maximum length of the generated response.
            temperature (float): Sampling temperature for diversity.
            top_k (int): Top-k sampling to consider top-k most probable tokens.
            top_p (float): Nucleus sampling to consider top tokens summing to top_p probability.

        Returns:
            str: The generated response.
        """
        # Tokenize the question
        inputs = tokenizer.encode(question, return_tensors="pt")
        
        # Generate a response using the model
        outputs = model.generate(
            inputs,
            max_length=max_length,
            temperature=temperature,
            top_k=top_k,
            top_p=top_p,
            num_return_sequences=1,
            no_repeat_ngram_size=2,
            early_stopping=False
        )
        
        # Decode and return the generated response
        return tokenizer.decode(outputs[0], skip_special_tokens=True)

    # Step 4: Test the model with a sample question
    question = (
        # "Answer the following question only if you have the knowledge. "
        "Question: write a small story for a kid"
    )

    # Generate and print the answer
    answer = generate_answer(question, model, tokenizer)
    print(f"Question: {question}\nAnswer: {answer}")




