# from transformers import AutoTokenizer
# from langchain_community.llms import Ollama

# model_name = Ollama(model="llama3.2")

# def check_token_length(texts, model_name):
#     tokenizer = AutoTokenizer.from_pretrained(model_name)
#     for idx, text in enumerate(texts):
#         tokens = tokenizer.tokenize(text)
#         if len(tokens) > 4096:  # Example token limit
#             print(f"Warning: Text at index {idx} exceeds token limit with {len(tokens)} tokens!")
#         else:
#             print(f"Text at index {idx} is within limit: {len(tokens)} tokens.")


from transformers import LlamaTokenizer

def check_token_length(texts, tokenizer_path="hf-internal-testing/llama-tokenizer"):
    # Initialize a tokenizer compatible with Llama
    tokenizer = LlamaTokenizer.from_pretrained(tokenizer_path)
    for idx, text in enumerate(texts):
        tokens = tokenizer.tokenize(text)
        if len(tokens) > 4096:  # Example token limit
            print(f"Warning: Text at index {idx} exceeds token limit with {len(tokens)} tokens!")
        else:
            print(f"Text at index {idx} is within limit: {len(tokens)} tokens.")
