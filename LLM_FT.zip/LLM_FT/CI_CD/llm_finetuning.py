# ########################################## LLM finetuning #################################

# import os
# from transformers import AutoTokenizer, AutoModelForCausalLM, Trainer, TrainingArguments
# from peft import LoraConfig, get_peft_model
# from datasets import Dataset

# #Step 1: Preprocess the training an validation datasets
# train_text = """Sk aka Saravanabramman is a dancer, actor and AI engineer. he lives in coimbatore.
#  He like to dance, act and travel. he is 29 years old. he is married. He was studied in govt school.
#    he did UG in "Robotics" at PSG college of technology,
#    and done his PG in "Machine learning" at Amrita university. he love his family. 
#    He is having 7 years of work experience. He love his job"""

# valid_text = """sk is born in coimbatore, he is a dance and singer."""

# dataset_path = r"C:\Users\saravana.kumar\Desktop\LLM_FT\CI_CD\formatted_dataset.txt"

# # Preprocess the data: Split text into individual lines and create dataset with 'text' field
# def preprocess_data(text):
#     return [{"text": chunk.strip()} for chunk in text.split("\n") if chunk.strip()]

# train_data = preprocess_data(train_text)
# valid_data = preprocess_data(valid_text)

# # Create Hugging Face datasets
# train_dataset = Dataset.from_list(train_data)
# valid_dataset = Dataset.from_list(valid_data)

# # Step 2: Load the tokenizer and set padding token
# model_name = "NousResearch/Llama-3.2-1B"  # Replace with the correct path to your local model
# tokenizer = AutoTokenizer.from_pretrained(model_name)
# tokenizer.pad_token = tokenizer.eos_token  # Use EOS token as PAD token

# # Tokenize datasets
# def tokenize_function(example):
#     tokens = tokenizer(
#         text=example["text"],  # Use the 'text' field directly
#         truncation=True,
#         padding="max_length",
#         max_length=512,
#     )
#     # Set labels to input_ids for causal language modeling
#     tokens["labels"] = tokens["input_ids"].copy()
#     return tokens

# tokenized_train_dataset = train_dataset.map(tokenize_function, batched=True)
# tokenized_valid_dataset = valid_dataset.map(tokenize_function, batched=True)

# # Step 3: Load the Llama model and apply LoRA for fine-tuning
# model = AutoModelForCausalLM.from_pretrained(model_name)

# lora_config = LoraConfig(
#     task_type="SEQ2SEQ_LM",
#     r=16,
#     lora_alpha=32,
#     lora_dropout=0.2
# )

# # lora_config = LoraConfig(
# #     task_type="CAUSAL_LM",
# #     r=4,
# #     lora_alpha=8,
# #     lora_dropout=0.3
# # )
# # model = get_peft_model(model, lora_config)

# # Step 4: Define training arguments
# training_args = TrainingArguments(
#     output_dir="llama3.2_v2",
#     per_device_train_batch_size=2,
#     gradient_accumulation_steps=8,
#     num_train_epochs=2,  # Start with fewer epochs
#     learning_rate=1e-4,
#     eval_strategy="steps",
#     eval_steps=10,
#     save_steps=50,
#     save_total_limit=2,
#     logging_dir="./logs",
#     logging_steps=10,
#     fp16=True,
#     optim="adamw_torch",
# )

# # Step 5: Initialize Trainer and start training
# trainer = Trainer(
#     model=model,
#     args=training_args,
#     train_dataset=tokenized_train_dataset,
#     eval_dataset=tokenized_valid_dataset,
#     tokenizer=tokenizer,
# )

# trainer.train()

# # Save the fine-tuned model and tokenizer
# save_path = "new_llama3.2_model_v2"
# os.makedirs(save_path, exist_ok=True)
# trainer.save_model(save_path)
# tokenizer.save_pretrained(save_path)

# print(f"Fine-tuning completed. Model and tokenizer saved to '{save_path}'")


import os
from transformers import AutoTokenizer, AutoModelForCausalLM, Trainer, TrainingArguments
from datasets import Dataset
from peft import LoraConfig, get_peft_model

def start_training(dataset_path, model_save_path):
    # Step 1: Load dataset from file
    with open(dataset_path, "r") as f:
        train_text = f.read()
    
    # Step 2: Preprocess the data
    train_data = [{"text": chunk.strip()} for chunk in train_text.split("\n") if chunk.strip()]
    train_dataset = Dataset.from_list(train_data)

    # Step 3: Load tokenizer and model
    model_name = "NousResearch/Llama-3.2-1B"  # Replace with the correct path
    tokenizer = AutoTokenizer.from_pretrained(model_name)
    tokenizer.pad_token = tokenizer.eos_token  # Use EOS token as PAD token

    # Tokenization function
    def tokenize_function(example):
        tokens = tokenizer(
            text=example["text"],
            truncation=True,
            padding="max_length",
            max_length=512,
        )
        tokens["labels"] = tokens["input_ids"].copy()
        return tokens

    tokenized_train_dataset = train_dataset.map(tokenize_function, batched=True)

    # Step 4: Set up the model
    model = AutoModelForCausalLM.from_pretrained(model_name)

    # Apply LoRA for fine-tuning
    lora_config = LoraConfig(
        task_type="SEQ2SEQ_LM",
        r=16,
        lora_alpha=32,
        lora_dropout=0.2
    )

    model = get_peft_model(model, lora_config)

    # Step 5: Set up training arguments
    training_args = TrainingArguments(
        output_dir=model_save_path,
        per_device_train_batch_size=2,
        gradient_accumulation_steps=8,
        num_train_epochs=1,
        learning_rate=1e-4,
        eval_strategy="steps",
        eval_steps=10,
        save_steps=50,
        save_total_limit=2,
        logging_dir="./logs",
        logging_steps=10,
        fp16=True,
        optim="adamw_torch",
    )

    # Step 6: Start training
    trainer = Trainer(
        model=model,
        args=training_args,
        train_dataset=tokenized_train_dataset,
        tokenizer=tokenizer,
    )

    trainer.train()

    # Step 7: Save the model
    os.makedirs(model_save_path, exist_ok=True)
    trainer.save_model(model_save_path)
    tokenizer.save_pretrained(model_save_path)

    print(f"Training complete! Model saved to {model_save_path}")
