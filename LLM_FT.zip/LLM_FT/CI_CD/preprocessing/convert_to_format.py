def format_for_finetuning(dataset):
    formatted_data = []
    for item in dataset:
        formatted_data.append(
            f"### Instruction:\n{item['question']}\n\n### Response:\n{item['answer']}\n"
        )
    return formatted_data
