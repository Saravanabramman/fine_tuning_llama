from preprocess_data import clean_dataset
from convert_to_format import format_for_finetuning
from check_token_limits import check_token_length
from llm_finetuning import start_training
from llm_validation import run_validation
import json

model_save_path= "V1_model"

def main():
    # File paths
    input_file = "dataset.json"
    cleaned_file ="cleaned_dataset1.json"
    formatted_file = "formatted_dataset1.txt"
    
    # Step 1: Clean the dataset
    print("Cleaning the dataset...")
    cleaned_data = clean_dataset(input_file)
    with open(cleaned_file, "w") as f:
        json.dump(cleaned_data, f, indent=4)
    print(f"Cleaned dataset saved to {cleaned_file}")

    # Step 2: Format for fine-tuning
    print("Formatting the dataset for fine-tuning...")
    formatted_data = format_for_finetuning(cleaned_data)
    with open(formatted_file, "w") as f:
        f.write("\n".join(formatted_data))
    print(f"Formatted dataset saved to {formatted_file}")

    # Step 3: Check token limits

    print("Checking token limits...")
    check_token_length(formatted_data, tokenizer_path="hf-internal-testing/llama-tokenizer")
    print("Token limit check completed.")


    #step 4: training the model using the preprocessed dataset
    start_training(formatted_file, model_save_path)

    #step 5: Validating the model using the test dataset
    run_validation()



if __name__ == "__main__":
    main()